//
//  DFMessageTableView.m
//  DFWeChatView
//
//  Created by Allen Zhong on 15/4/18.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFMessageTableView.h"


@interface DFMessageTableView()

//@property (strong, nonatomic) UITableView *table;
@end


@implementation DFMessageTableView



#pragma mark - Lifecycle

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initView];
    }
    return self;
}


-(void) initView
{
   //self.backgroundColor = [UIColor greenColor];
    
    //self.separatorStyle = UITableViewCellSelectionStyleNone;
    
    
//    if (_table == nil) {
//        _table = [[UITableView alloc] initWithFrame:self.frame];
//        [self addSubview:_table];
//        _table.delegate = self;
//        _table.dataSource = self;
//    }
    
    
    
    UILabel *bottomLable = [[UILabel alloc] initWithFrame:CGRectMake(0, self.frame.size.height-50, self.frame.size.width, 50)];
   // [self addSubview:bottomLable];
    bottomLable.backgroundColor = [UIColor redColor];
    bottomLable.text = @"消息底部";
    
}



@end
