//
//  DFInputToolbarView.m
//  DFWeChatView
//
//  Created by Allen Zhong on 15/4/17.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFInputToolbarView.h"

#define BgColor [UIColor colorWithWhite:245/255.0 alpha:1.0]
#define TopLineColor [UIColor colorWithWhite:200/255.0 alpha:1.0]
#define TextViewBorderColor [UIColor colorWithWhite:175/255.0 alpha:1.0]

#define InputVoiceBtnBgColor [UIColor colorWithWhite:245/255.0 alpha:1.0]
#define InputVoiceBtnBorderColor [UIColor colorWithWhite:175/255.0 alpha:1.0]

#define HorizontalBtnPadding 3
#define VerticalBtnPadding 7.5
#define BtnSize 35


//左边按钮状态
typedef NS_ENUM(NSUInteger, TextVoiceBtnState){
    TextVoiceBtnStateText,
    TextVoiceBtnStateVoice
};

//右边笑脸按钮状态
typedef NS_ENUM(NSUInteger, EmotionsBtnState){
    EmotionsBtnStateEmotions,
    EmotionsBtnStateText
};


//中间文本框和语音按钮状态
typedef NS_ENUM(NSUInteger, InputVoiceAndTextviewState){
    InputVoiceAndTextviewStateTextview,
    InputVoiceAndTextviewStateVoice
};




@interface DFInputToolbarView()

@property (nonatomic, assign) InputToolbarState toolbarState;

@property (strong,nonatomic) UIButton *textVoiceBtn;

@property (strong,nonatomic) UIButton *emotionsBtn;

@property (strong,nonatomic) UIButton *pluginsBtn;


@property (strong,nonatomic) UITextView *inputTextView;
@property (strong,nonatomic) UIButton *inputVoiceBtn;

@end

@implementation DFInputToolbarView


#pragma mark - Lifecycle

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)dealloc
{
    
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _toolbarState = InputToolbarStateNone;
        
        [self initView];
    }
    return self;
}

-(void) initView
{
    self.backgroundColor = BgColor;
    
    CGFloat x, y ,width,height;

    
    //顶部横线
    UIView *topLineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 0.5)];
    topLineView.backgroundColor = TopLineColor;
    [self addSubview:topLineView];
    
    
    //文本语音
    x = HorizontalBtnPadding;
    width = BtnSize;
    height = BtnSize;
    y = CGRectGetHeight(self.frame) - VerticalBtnPadding - height;
    
    if (_textVoiceBtn == nil) {
        _textVoiceBtn = [[UIButton alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self addSubview:_textVoiceBtn];
        [_textVoiceBtn addTarget:self action:@selector(onClickTextVoiceBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self switchTextVoiceBtnState:TextVoiceBtnStateVoice];
        
    }
    
    
    //表情
    x = CGRectGetWidth(self.frame) - (HorizontalBtnPadding + BtnSize)*2;
    
    if (_emotionsBtn == nil) {
        _emotionsBtn = [[UIButton alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self addSubview:_emotionsBtn];
        
        [self switchEmotionsBtnState:EmotionsBtnStateEmotions];
        
        [_emotionsBtn addTarget:self action:@selector(onClickEmotionBtn:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    
    //插件
    
    x = x+BtnSize+HorizontalBtnPadding;
    if (_pluginsBtn == nil) {
        _pluginsBtn = [[UIButton alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [_pluginsBtn setImage:[UIImage imageNamed:@"ToolViewPlugin"] forState:UIControlStateNormal];
        [_pluginsBtn setImage:[UIImage imageNamed:@"ToolViewPluginHL"] forState:UIControlStateSelected];
        [self addSubview:_pluginsBtn];
        [_pluginsBtn addTarget:self action:@selector(onClickPluginsBtn:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    
    
    x = CGRectGetMaxX(_textVoiceBtn.frame) + HorizontalBtnPadding*2;
    width = CGRectGetMinX(_emotionsBtn.frame) - x  - HorizontalBtnPadding*2;
    
    if (_inputTextView == nil) {
        _inputTextView = [[UITextView alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self addSubview:_inputTextView];
        
        _inputTextView.keyboardType = UIKeyboardTypeDefault;
        _inputTextView.returnKeyType = UIReturnKeySend;
        _inputTextView.layer.borderWidth = 0.5;
        _inputTextView.layer.cornerRadius = 5;
        _inputTextView.layer.borderColor = TextViewBorderColor.CGColor;
        _inputTextView.font = [UIFont systemFontOfSize:15];
    }
    
    if (_inputVoiceBtn == nil) {
        _inputVoiceBtn = [[ UIButton alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self addSubview:_inputVoiceBtn];
        
        _inputVoiceBtn.backgroundColor = InputVoiceBtnBgColor;
        _inputVoiceBtn.layer.borderWidth = 0.5;
        _inputVoiceBtn.layer.cornerRadius = 5;
        _inputVoiceBtn.layer.borderColor = InputVoiceBtnBorderColor.CGColor;
        [_inputVoiceBtn setTitle:@"按住 说话" forState:UIControlStateNormal];
        [_inputVoiceBtn setTitleColor:[UIColor colorWithWhite:100/255.0 alpha:1.0] forState:UIControlStateNormal];
        _inputVoiceBtn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateTextview];
    }
    
}



#pragma mark - Btn State Change
-(void) switchTextVoiceBtnState:(TextVoiceBtnState) state
{
    switch (state) {
        case TextVoiceBtnStateText:
            [_textVoiceBtn setImage:[UIImage imageNamed:@"ToolViewKeyboard"] forState:UIControlStateNormal];
            [_textVoiceBtn setImage:[UIImage imageNamed:@"ToolViewKeyboardHL"] forState:UIControlStateSelected];
            break;
        case TextVoiceBtnStateVoice:
            [_textVoiceBtn setImage:[UIImage imageNamed:@"ToolViewInputVoice"] forState:UIControlStateNormal];
            [_textVoiceBtn setImage:[UIImage imageNamed:@"ToolViewInputVoiceHL"] forState:UIControlStateSelected];
            break;
        default:
            break;
    }
}



-(void) switchEmotionsBtnState:(EmotionsBtnState) state
{
    switch (state) {
        case EmotionsBtnStateText:
            [_emotionsBtn setImage:[UIImage imageNamed:@"ToolViewKeyboard"] forState:UIControlStateNormal];
            [_emotionsBtn setImage:[UIImage imageNamed:@"ToolViewKeyboardHL"] forState:UIControlStateSelected];
            break;
        case EmotionsBtnStateEmotions:
            [_emotionsBtn setImage:[UIImage imageNamed:@"ToolViewEmotion"] forState:UIControlStateNormal];
            [_emotionsBtn setImage:[UIImage imageNamed:@"ToolViewEmotionHL"] forState:UIControlStateSelected];
            break;
        default:
            break;
    }
}



-(void) switchInputVoiceAndTextviewState:(InputVoiceAndTextviewState) state
{
    switch (state) {
        case InputVoiceAndTextviewStateVoice:
        {
            _inputTextView.hidden = YES;
            _inputVoiceBtn.hidden = NO;
            break;
        }
        
        case InputVoiceAndTextviewStateTextview:
        {
            _inputVoiceBtn.hidden = YES;
            _inputTextView.hidden = NO;
            break;
        }
        default:
            break;
    }
}



#pragma mark - Btn On Click

-(void) onClickTextVoiceBtn:(id) sender
{
    switch (_toolbarState) {
        case InputToolbarStateNone:
        {
            [self switchTextVoiceBtnState:TextVoiceBtnStateText];
            [self switchEmotionsBtnState:EmotionsBtnStateEmotions];
            _toolbarState = InputToolbarStateVoice;
            [_inputTextView resignFirstResponder];
            [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateVoice];
            break;
        }
        case InputToolbarStateVoice:
        {
            [self switchTextVoiceBtnState:TextVoiceBtnStateVoice];
            _toolbarState = InputToolbarStateText;
            [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateTextview];
            [_inputTextView becomeFirstResponder];
            
            break;
        }
        case InputToolbarStateText:
        {
            [self switchTextVoiceBtnState:TextVoiceBtnStateText];
            [self switchEmotionsBtnState:EmotionsBtnStateEmotions];
            _toolbarState = InputToolbarStateVoice;
            [_inputTextView resignFirstResponder];
            [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateVoice];
            break;
        }
        case InputToolbarStateEmotions:
        {
            [self switchTextVoiceBtnState:TextVoiceBtnStateText];
            [self switchEmotionsBtnState:EmotionsBtnStateEmotions];
            _toolbarState = InputToolbarStateVoice;
            [_inputTextView resignFirstResponder];
            [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateVoice];
            break;
        }
        case InputToolbarStatePlugins:
        {
             _toolbarState = InputToolbarStateVoice;
             [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateVoice];
        }
            
        default:
            break;
    }
    
    if (_delegate != nil && [_delegate conformsToProtocol:@protocol(DFInputToolbarViewDelegate)]  && [_delegate respondsToSelector:@selector(onClickTextAndVoiceBtn)]) {
        [_delegate onClickTextAndVoiceBtn];
    }
    
}





-(void) onClickEmotionBtn:(id) sender
{
    switch (_toolbarState) {
        case InputToolbarStateNone:
        case InputToolbarStateVoice:
        {
            [self switchEmotionsBtnState:EmotionsBtnStateText];
            [self switchTextVoiceBtnState:TextVoiceBtnStateVoice];
            _toolbarState = InputToolbarStateEmotions;
            [_inputTextView resignFirstResponder];
            [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateTextview];
            break;
        }
        case InputToolbarStateEmotions:
        {
             [self switchEmotionsBtnState:EmotionsBtnStateEmotions];
            _toolbarState = InputToolbarStateText;
            [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateTextview];
            [_inputTextView becomeFirstResponder];
            
            break;
        }
        case InputToolbarStateText:
        {
            [self switchEmotionsBtnState:EmotionsBtnStateText];
            [self switchTextVoiceBtnState:TextVoiceBtnStateVoice];
            _toolbarState = InputToolbarStateEmotions;
            [self switchInputVoiceAndTextviewState:InputVoiceAndTextviewStateTextview];
            [_inputTextView resignFirstResponder];
            break;
        }
        case InputToolbarStatePlugins:
        {
            [self switchEmotionsBtnState:EmotionsBtnStateText];
            [self switchTextVoiceBtnState:TextVoiceBtnStateVoice];
            _toolbarState = InputToolbarStateEmotions;
        }
        default:
            break;
    }
    
    if (_delegate != nil && [_delegate conformsToProtocol:@protocol(DFInputToolbarViewDelegate)]  && [_delegate respondsToSelector:@selector(onClickEmotionsBtn)]) {
        [_delegate onClickEmotionsBtn];
    }
    
    
}





-(void) onClickPluginsBtn:(id) sender
{
    switch (_toolbarState) {
        case InputToolbarStateNone:
        {
            _toolbarState = InputToolbarStatePlugins;
            [_inputTextView resignFirstResponder];
            break;
        }
        case InputToolbarStateVoice:
        {
            _toolbarState = InputToolbarStatePlugins;
            [_inputTextView resignFirstResponder];
            
            break;
        }
        case InputToolbarStateText:
        {
            _toolbarState = InputToolbarStatePlugins;
            [_inputTextView resignFirstResponder];

            
            break;
        }
        case InputToolbarStateEmotions:
        {
            _toolbarState = InputToolbarStatePlugins;
            break;
        }
        case InputToolbarStatePlugins:
        {
            [_inputTextView becomeFirstResponder];
            _toolbarState = InputToolbarStateText;
            
        }
            
        default:
            break;
    }
    
    
    if (_delegate != nil && [_delegate conformsToProtocol:@protocol(DFInputToolbarViewDelegate)]  && [_delegate respondsToSelector:@selector(onClickPluginsBtn)]) {
        [_delegate onClickPluginsBtn];
    }
    
}




#pragma mark - Method
-(InputToolbarState) getInputToolbarState
{
    return _toolbarState;
}


@end
