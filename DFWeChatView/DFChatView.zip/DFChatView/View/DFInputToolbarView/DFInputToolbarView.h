//
//  DFInputToolbarView.h
//  DFWeChatView
//
//  Created by Allen Zhong on 15/4/17.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//整个输入栏状态
typedef NS_ENUM(NSUInteger, InputToolbarState){
    InputToolbarStateNone,
    InputToolbarStateText,
    InputToolbarStateVoice,
    InputToolbarStateEmotions,
    InputToolbarStatePlugins
};


@protocol DFInputToolbarViewDelegate <NSObject>

@required
-(void) onClickTextAndVoiceBtn;
-(void) onClickEmotionsBtn;
-(void) onClickPluginsBtn;

@optional


@end



@interface DFInputToolbarView : UIView

@property (assign,nonatomic) id<DFInputToolbarViewDelegate> delegate;



-(InputToolbarState) getInputToolbarState;



@end
