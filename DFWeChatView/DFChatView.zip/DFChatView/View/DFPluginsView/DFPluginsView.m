//
//  DFPluginsView.m
//  DFWeChatView
//
//  Created by Allen Zhong on 15/4/18.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFPluginsView.h"


@interface DFPluginsView()

@end


@implementation DFPluginsView

#pragma mark - Lifecycle

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initView];
    }
    return self;
}


-(void) initView
{
    self.backgroundColor = [UIColor colorWithWhite:235/255.0 alpha:1.0];
    
    UILabel *topLable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 50)];
    [self addSubview:topLable];
    topLable.backgroundColor = [UIColor greenColor];
    topLable.text = @"插件顶部";

}



@end
