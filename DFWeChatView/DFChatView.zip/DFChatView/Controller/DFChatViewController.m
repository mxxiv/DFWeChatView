//
//  DFChatViewController.m
//  DFWeChatView
//
//  Created by Allen Zhong on 15/4/17.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFChatViewController.h"

#define InputToolbarViewHeight 50
#define PluginsViewHeight 216
#define EmotionsViewHeight 216

#define ToolBarObserveKeyPath @"toolbarViewOffsetY"

#define AnimationDuration 0.2500


@interface DFChatViewController ()

@property (assign, nonatomic) CGFloat toolbarViewOffsetY;


@property (strong, nonatomic) DFInputToolbarView *inputToolbarView;

@property (strong, nonatomic) DFMessageTableView *messageTableView;

@property (strong, nonatomic) DFPluginsView *pluginsView;

@property (strong, nonatomic) DFEmotionsView *emotionssView;


@end


@implementation DFChatViewController


#pragma mark - Lifecycle


- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)dealloc
{
    [self removeNotify];
    
    [self removeObserver];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initView];
    
    [self addNotify];
    
    [self addObserver];
}


-(void) initView
{
    self.view.backgroundColor = [UIColor colorWithWhite:235/255.0 alpha:1.0];
    
    CGFloat x, y ,width,height;
    
    
    //输入工具栏
    x = 0.0f;
    y = CGRectGetHeight(self.view.frame) - InputToolbarViewHeight ;
    width = CGRectGetWidth(self.view.frame);
    height = InputToolbarViewHeight;
    
    if (_inputToolbarView == nil) {
        _inputToolbarView = [[DFInputToolbarView alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self.view addSubview:_inputToolbarView];
        _inputToolbarView.delegate = self;
        
        _toolbarViewOffsetY = y;
        
    }
    
    //消息表格
    y = 0;
    height = CGRectGetMinY(_inputToolbarView.frame);
    
    if (_messageTableView == nil) {
        _messageTableView = [[DFMessageTableView alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self.view addSubview:_messageTableView];
        _messageTableView.delegate = self;
        _messageTableView.dataSource = self;
        
        
    }
    
    
    //插件面板
    
    y = CGRectGetMaxY(_inputToolbarView.frame);
    height = PluginsViewHeight;
    if (_pluginsView == nil) {
        _pluginsView = [[DFPluginsView alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self.view addSubview:_pluginsView];
        _pluginsView.hidden = YES;
    }
    
    
    //表情面板
    
    height = EmotionsViewHeight;
    if (_emotionssView == nil) {
        _emotionssView = [[DFEmotionsView alloc] initWithFrame:CGRectMake(x, y, width, height)];
        [self.view addSubview:_emotionssView];
        _emotionssView.hidden = YES;
    }
    
    
    [self.view bringSubviewToFront:_inputToolbarView];
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //[self messageTableViewscrollToBottom];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}




#pragma mark - Notification

-(void) addNotify

{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onKeyboradShow:) name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onKeyboradHide:) name:UIKeyboardWillHideNotification object:nil];
    
}


-(void) removeNotify

{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
}

-(void) onKeyboradShow:(NSNotification *) notify
{
    [self onKeyboardChange:notify];
    
}


-(void) onKeyboradHide:(NSNotification *) notify
{
    //[self onKeyboardChange:notify];
    
}

-(void) onKeyboardChange:(NSNotification *) notify
{
    NSDictionary *info = notify.userInfo;
    
    CGRect frame = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    //CGFloat height = frame.size.height;
    NSTimeInterval duration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    NSLog(@"durationg: %f",duration);
    
    [self changeInputToolbarViewOffsetY:(frame.origin.y - InputToolbarViewHeight) ];
}


#pragma mark - Observer

-(void) addObserver
{
    [self addObserver:self forKeyPath:ToolBarObserveKeyPath options:NSKeyValueObservingOptionNew context:nil];
}


-(void) removeObserver
{
    [self removeObserver:self forKeyPath:ToolBarObserveKeyPath];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ([keyPath isEqualToString:ToolBarObserveKeyPath]) {
        
        NSLog(@"%@",change);
        CGFloat newOffsetY = [[change valueForKey:NSKeyValueChangeNewKey] floatValue];
        [self changeInputToolbarViewPosition:newOffsetY];
    }
    
}

-(void) changeInputToolbarViewOffsetY:(CGFloat) offsetY
{
    [self setValue: [NSNumber numberWithDouble:offsetY] forKey:ToolBarObserveKeyPath];
    
}

-(void) changeInputToolbarViewPosition:(CGFloat) newOffsetY
{
    CGFloat x,y,width,height;
    CGRect frame = _inputToolbarView.frame;
    x = frame.origin.x;
    y = newOffsetY;
    width = frame.size.width;
    height = frame.size.height;
    
    [UIView animateWithDuration:AnimationDuration animations:^{
        _inputToolbarView.frame = CGRectMake(x, y, width, height);
        
        [self changeMessageTableViewPosition:newOffsetY];
        [self changeEmotionsViewPosition:newOffsetY];
        [self changePluginsViewPosition:newOffsetY];
    }];
    
    
    
}

-(void) changeMessageTableViewPosition:(CGFloat) newOffsetY {
    CGFloat x,y,width,height;
    CGRect frame = _messageTableView.frame;
    x = frame.origin.x;
    y = frame.origin.y;
    width = frame.size.width;
    height = newOffsetY;
    _messageTableView.frame = CGRectMake(x, y, width, height);
    
    [self messageTableViewscrollToBottom];
}


-(void) changeEmotionsViewPosition:(CGFloat) newOffsetY {
    CGFloat x,y,width,height;
    CGRect frame = _messageTableView.frame;
    x = frame.origin.x;
    y = newOffsetY + InputToolbarViewHeight;
    width = frame.size.width;
    height = frame.size.height;
    _emotionssView.frame = CGRectMake(x, y, width, height);
}

-(void) changePluginsViewPosition:(CGFloat) newOffsetY {
    CGFloat x,y,width,height;
    CGRect frame = _messageTableView.frame;
    x = frame.origin.x;
    y = newOffsetY + InputToolbarViewHeight;
    width = frame.size.width;
    height = frame.size.height;
    _pluginsView.frame = CGRectMake(x, y, width, height);
}



#pragma mark - DFInputToolbarViewDelegate

-(void)onClickEmotionsBtn
{
    if ([_inputToolbarView getInputToolbarState] != InputToolbarStateText) {
    CGFloat offsetY = CGRectGetHeight(self.view.frame) - InputToolbarViewHeight - PluginsViewHeight ;
    [self changeInputToolbarViewPosition:offsetY];
    }
    
    _emotionssView.hidden = NO;
    _pluginsView.hidden = YES;
    
}

-(void)onClickTextAndVoiceBtn
{
    if ([_inputToolbarView getInputToolbarState] != InputToolbarStateText) {
        CGFloat offsetY = CGRectGetHeight(self.view.frame) - InputToolbarViewHeight  ;
        [self changeInputToolbarViewPosition:offsetY];
    }
    
    
}

-(void)onClickPluginsBtn
{
    if ([_inputToolbarView getInputToolbarState] != InputToolbarStateText) {
    CGFloat offsetY = CGRectGetHeight(self.view.frame) - InputToolbarViewHeight - PluginsViewHeight ;
    [self changeInputToolbarViewPosition:offsetY];
    }
    
    _emotionssView.hidden = YES;
    _pluginsView.hidden = NO;
}





#pragma mark - Method MessageTableView

-(void) messageTableViewscrollToBottom
{
    //[_messageTableView setContentOffset:CGPointMake(0, _messageTableView.contentSize.height -_messageTableView.bounds.size.height) animated:NO];
}





#pragma mark - UITableViewDataSource & Delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 15;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.text = [NSString stringWithFormat:@"%ld", (long)indexPath.row];
    return cell;
}


@end
