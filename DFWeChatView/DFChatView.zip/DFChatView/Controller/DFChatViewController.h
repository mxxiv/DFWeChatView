//
//  DFChatViewController.h
//  DFWeChatView
//
//  Created by Allen Zhong on 15/4/17.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//main components
#import "DFInputToolbarView.h"
#import "DFMessageTableView.h"
#import "DFPluginsView.h"
#import "DFEmotionsView.h"


@interface DFChatViewController : UIViewController<UITableViewDelegate,UITableViewDataSource, DFInputToolbarViewDelegate>

@end
